function alerta () {
    alert("Ainda em construção, pedimos paciência!")
}